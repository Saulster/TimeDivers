TIME DIVERS

OVERVIEW

HOW TO RUN 
Unzip the Project folder called OPSC7311_ST10136414_JonathanBezuidenhout.zip or Timedivers_JonathanBezuidenhout_ST10136414_ST10072411_ST10108388_ST10202241.zip 
or clone repository https://github.com/ST10136414/OPSC7311_ST10136414_JonathanBezuidenhout or https://github.com/VCCT-OPSC7311-G1-2024/Timedivers_JonathanBezuidenhout_ST10136414_ST10072411_ST10108388_ST10202241
then open the app in Android studio and sync project files with gradle and then run it on the emulator.

FEATURES including 2 added features 
-Sign in page 
  The user is able to log in to an account that they have created previously or create a new account 
  
-Sign Up page 
  The User is able to create an account with timedivers by using their email
  
-Timer 
  The user can activate a timer this was one of the 2 added features
  
-Profile feature
  The user can view their profile and upload a photo to their profile, one of the 2 added features
  
-Project creation
  A user can create a project for users to collaborate on or viewed later 
  
-Entry creation 
  An Timesheet entry can be added to a specific project and can be viewed later  
  
-Navbar feature 
  allows the user to navigate between all the pages like Dashboard, Timesheet, Timer and report and more options
  
-More options page
  user can go to Territory Page, Goals and profile page from this page 
  
-Goals Feature 
  the user is able to input organisational goals that need to be met, and specifiy the dates on week these goals must be met with a daily and weekly basis
  
-Database storage 
  User data is stored in a Firebase Database 
  
-Forgot password feature 
  A user is able to reset password if forgotten 
  
-Graph feature 
  Can be viewed from the dashboard page 
-Total Hours worked
  User can view the total hours worked on a project in a date range 
  
-Territory Feature 
  User can track how much they are working and compete with others
  


TECHNOLOGY Used
Android Studio
Firebase


AUTHORS 
ST10136414 Jonathan Bezuidenhout  
ST10072411 Brice Agnew
ST10108388 Aiden Byrne
ST10202241 Salih Adams

