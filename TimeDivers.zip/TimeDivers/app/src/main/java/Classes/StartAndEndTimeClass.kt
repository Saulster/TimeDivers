package Classes

import java.sql.Time


class StartAndEndTimeClass
{
    lateinit var startTime:String
    lateinit var endTime:String
    lateinit var totalLoggedTime:String
}